import Vue from 'vue'
Vue.prototype.$eventBus = new Vue();