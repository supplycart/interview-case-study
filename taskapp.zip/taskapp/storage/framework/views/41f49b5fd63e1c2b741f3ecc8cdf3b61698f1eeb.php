<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row">
                    <?php $__currentLoopData = $allproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-sm-6">
                        <div class="card">
                          <div class="card-body">
                            <img src=" <?php echo e(asset('productphoto')."/".$item->photo); ?>" alt="" class="img-thumbnail">
                            <h5 class="card-title"><?php echo e($item->name); ?></h5>
                            <h6 class="card-text"><?php echo e($item->brand); ?></h6>
                            <p class="card-text"><?php echo e($item->price); ?></p>
                            <p class="card-text"><?php echo e($item->category); ?></p>
                            <a href="#" class="btn btn-primary">Add to cart</a>
                          </div>
                        </div>
                      </div>
        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        
                    </div>

                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aladdin/project/taskapp/resources/views/products.blade.php ENDPATH**/ ?>