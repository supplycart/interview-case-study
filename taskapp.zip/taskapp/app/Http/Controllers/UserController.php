<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
    //

    public function getpurchase(Request $request)
    {
        // make purachase

        
    }
}
