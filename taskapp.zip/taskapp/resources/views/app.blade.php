<!Doctype   HTML>
<html lang="en-us">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <title> Supply Cart</title>
        
        <link rel="stylesheet" href="">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="{{ mix('css/app.css')}}">

    </head>
    <body class="antialiased">
        <div class="container mx-auto">
            <div id="app"></div>
        </div>
        <script src="{{ mix ('js/app.js')}}"></script>
    </body>


</html>